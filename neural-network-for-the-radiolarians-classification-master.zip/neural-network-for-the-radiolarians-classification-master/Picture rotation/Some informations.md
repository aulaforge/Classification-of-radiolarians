Here is a link where you can find the script (it's the same than here), with the first images sample that I had. You can test the script by downloading the directory in the link (there is some practical help in it).

The script works by founding the "symetry axis", to rotate it and align it with the diagonal, then resizing the image.

