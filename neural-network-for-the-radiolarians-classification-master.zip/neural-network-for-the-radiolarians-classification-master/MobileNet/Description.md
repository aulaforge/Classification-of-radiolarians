test-mobile : test of MobileNet with the Fashion MNIST dataset. It's a "fast" test that can be extended (more steps for example) to have better results. The aim was just to test my MobileNet implementation.

mobilenet-on-radiolarians : MobileNet applied on the radiolarian data set.