# Neural network for the radiolarians classification


You can find here all my work about Veronica Carlsson's research
